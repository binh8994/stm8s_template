See https://stm8-binutils-gdb.sourceforge.io/ for installation and usage.
